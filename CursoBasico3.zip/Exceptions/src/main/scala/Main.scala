object Main {
  def dividir (n1: Int, n2: Int): Float = {
    n1/n2
  }

  def edadCarnet(edad: Int): Unit = {
    if (edad<18) {
      throw new Exception(("No tienes edad de conducir"))
    }
    println("Carnet concedido")
  }

  def main(args: Array[String]): Unit = {
    try {
      println(dividir(10,1))
      //val array1= Array(1,5,7)
      //array1(90)
      println(edadCarnet(10))
    } catch {
      case e: ArithmeticException => println("Se ha producido la excepción aritmetica: " + e)
      case ea: ArrayIndexOutOfBoundsException => println("Vigilar con errores de indice: " + ea)
      case ex: RuntimeException => println("Se ha producido la excepción: " + ex)
      case ex1: Throwable => println(("Se ha producido la excepción " + ex1))
    } finally {
      println("Siempre se ejecuta")
    }
  }
}