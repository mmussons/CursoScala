import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.functions.{col, to_date}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.sql.types.{StringType, StructField, StructType}

object StructTipes extends App {
  val logger: Logger = Logger.getLogger(getClass.getName)

  val sparkAppConf = new SparkConf().setAppName("Manual DF").setMaster("local[3]")
  val spark = SparkSession.builder()
    .config(sparkAppConf)
    .getOrCreate()
  spark.sparkContext.setLogLevel("WARN")

  val mySchema = StructType(List(
    StructField("ID",StringType),
    StructField("EventDate", StringType)
  ))
  val myRows = List(Row("123","04/05/2020"), Row("124","4/5/2020"), Row("125","1/1/2023"))
  val myRDD = spark.sparkContext.parallelize(myRows,2)
  val myDF = spark.createDataFrame(myRDD, mySchema)

  myDF.printSchema()
  myDF.show()

  def toDateDF(df: DataFrame, fmt: String, fld: String): DataFrame = {
    df.withColumn(fld, to_date(col(fld), fmt))
  }

  val newDF = toDateDF(myDF, "M/d/y", "EventDate")
  newDF.printSchema()
  newDF.show()
}
