import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.substring_index

case class ApacheLogRecord(ip: String, date: String, request: String, referrer: String)

object LogFileDemo extends App {
  //Comentario alias
  type LS = List[String]
  val value: LS = List("a", "b")

  //Ejemplo log files
  val spark = SparkSession.builder()
    .appName("Log File Demo")
    .master("local[3]")
    .getOrCreate()

  val logsDF = spark.read.textFile("src/datos/apache_logs.txt").toDF()

  val myReg = """^(\S+) (\S+) (\S+) \[([\w:/]+\s[+\-]\d{4})\] "(\S+) (\S+) (\S+)" (\d{3}) (\S+) "(\S+)" "([^"]*)"""".r

  import spark.implicits._

  val logDF = logsDF.map(row =>
    row.getString(0) match {
      case myReg(ip, client, user, date, cmd, request, proto, status, bytes, referrer, userAgent) =>
        (ip, date, request, referrer)
    }
  )
  logDF.show()

  val logDF1 = logsDF.map(row =>
    row.getString(0) match {
      case myReg(ip, client, user, date, cmd, request, proto, status, bytes, referrer, userAgent) =>
        ApacheLogRecord(ip, date, request, referrer)
    }
  )
  logDF1.show()

  logDF1
    .where("trim(referrer) != '-' ")
    .groupBy("referrer").count().show(truncate = false)

  logDF1
    .where("trim(referrer) != '-' ")
    .withColumn("referrer", substring_index($"referrer","/",3))
    .groupBy("referrer").count().show(truncate = false)

  spark.stop()

}
