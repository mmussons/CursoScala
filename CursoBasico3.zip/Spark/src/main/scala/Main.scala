import org.apache.spark.SparkConf
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.log4j.Logger

import java.util.Properties
import scala.io.Source

object Main {
  val logger: Logger = Logger.getLogger(getClass.getName)

  def main(args: Array[String]): Unit = {
    println("Hello world!")

    //Spark session versión 1
    /*val spark = SparkSession.builder()
      .appName("Hello spark")
      .master("local[3]")
      .getOrCreate()*/

    //Sparksession utilizando sparkconf
    /*val sparkAppConf = new SparkConf()
    sparkAppConf.set("spark.app.name","Hello Spark")
    sparkAppConf.set("spark.master","local[3]")
    val spark = SparkSession.builder()
      .config(sparkAppConf)
      .getOrCreate()*/

    //Sparksession utilizando sparkconf a partir de un archivo
    val spark = SparkSession.builder()
      .config(getSparkConf)
      .getOrCreate()

    //Carga de datos
    val fileCSV = "src/datos/sample.csv"
    /*val surveyDF = spark.read
      .option("header","true")
      .option("inferSchema","true")
      .csv(fileCSV)
    surveyDF.show()*/

    val surveyRawDF = loadSurveyDF(spark, fileCSV)
    //surveyRawDF.show()

    val partitionedSurveyDF = surveyRawDF.repartition(2)
    surveyRawDF.where("Age < 40").show()
    val selectSurveyRawDF = surveyRawDF.select("Age","Gender","Country","state")
    val filteredSurveyRawDF = selectSurveyRawDF.where("Age < 40")
    val groupedSurveyRawDF = filteredSurveyRawDF.groupBy("Country")
    val countDF = groupedSurveyRawDF.count()
    //countDF.show()

    surveyRawDF.select("Age","Gender","Country","state")
      .where("Age < 40")
      .groupBy("Country")
      .count()
      .show()

    //Se puede sustituir
    val countDF1 = countByCountry(partitionedSurveyDF)
    countDF1.foreach(row => {
      logger.info("Country: " + row.getString(0) + " Count: " + row.getLong(1))
    })
    //logger.info(countDF.collect().mkString("->"))

    //Otro ejemplo mediante vista temporal
    surveyRawDF.printSchema()
    surveyRawDF.createTempView("sampleUsers")
    val sampleSqlDF = spark.sql("select Age, Gender, Country, state from sampleUsers")
    sampleSqlDF.show()

    spark.stop()
  }

  def countByCountry(surveyDF: DataFrame): DataFrame = {
    surveyDF.select ("Age", "Gender", "Country", "state")
    .where ("Age < 40")
    .groupBy ("Country")
    .count ()
  }

  //Funcion de carga configuración de spark session
  def getSparkConf: SparkConf = {
    val sparkAppConf = new SparkConf()
    val props = new Properties()
    props.load(Source.fromFile("spark.conf").bufferedReader())
    props.forEach((k, v) => sparkAppConf.set(k.toString, v.toString))
    sparkAppConf
  }

  def loadSurveyDF(spark: SparkSession, dataFile: String): DataFrame = {
    spark.read
      .option("header","true")
      .option("inferSchema","true")
      .csv(dataFile)
  }
}