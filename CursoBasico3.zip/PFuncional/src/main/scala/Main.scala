object Main extends App {

  //Programación funcional
  def suma(a: Int, b: Int): Int = a + b

  //función sintaxis explicita
  val getNameLengthVal: (String, String) => Int = (name, name1) => name.length + name1.length
  val multiplyByTwoVal: Int => Int = numero => numero * 2

  //función sintaxis implícita
  val getNameLenghtVal2 = (name: String, name1: String) => name.length + name1.length
  val multiplyByTwoVal2 = (numero: Int) => numero * 2

  println(getNameLengthVal("hola", "scala"))
  println(multiplyByTwoVal(4))

  println(getNameLenghtVal2("hola", "scala"))
  println(multiplyByTwoVal2(4))

  //Como llegamos a utilizar programación funcional dentro la JVM

  trait MyFunction[A, B] {
    def apply(element: A): B
  }

  val doubler = new MyFunction[Int, Int] {
    override def apply(element: Int): Int = element * 2
  }

  /*class doubler(element: Int) extends MyFunction[Int, Int]{
    override def apply(element: Int): Int = element * 2
  }
  val db = new doubler(2)*/

  println(doubler.apply(2))
  println(doubler(2))

  //Function1, Function2, ... Function22
  val stringToIntConverter = new Function[String, Int] {
    override def apply(v1: String): Int = v1.toInt
  }

  println(stringToIntConverter("3") * 7)

  val adder = new Function2[Int, Int, Int] {
    override def apply(v1: Int, v2: Int): Int = v1 + v2
  }
  println(adder(1, 2))

  val adder2: Function2[Int, Int, Int] = new Function2[Int, Int, Int] {
    override def apply(v1: Int, v2: Int): Int = v1 + v2
  }
  println(adder2(1, 2))

  val adder3: ((Int, Int) => Int) = new Function2[Int, Int, Int] {
    override def apply(v1: Int, v2: Int): Int = v1 + v2
  }
  println(adder3(1, 2))

  //Function2[A, B, R] en (A, B) => R
  val adder4: (Int, Int) => Int = (v1, v2) => v1 + v2
  val adder5 = (v1: Int, v2: Int) => v1 + v2

  println(adder4(1, 2))
  println(adder5(1, 2))

  //Higher-Order functions
  def calAnything(number: Int, calcFunction: Int => Int): Int = calcFunction(number)

  def calSquare(num: Int): Int = num * num

  def calCube(num: Int): Int = num * num * num

  var squareCalculated = calAnything(2, calSquare)
  val cubeCalculated = calAnything(2, calCube)
  println(squareCalculated, cubeCalculated)

  //Ejercicio: pasar funcion como parámetro, que utilice 2 valores para sumar, restar, multiplicar.
  def performArithmeticOper(num1: Int, num2: Int, f: (Int, Int) => Int): Int = f(num1, num2)

  def performAddition(x: Int, y: Int): Int = x + y

  def performSubtraction(x: Int, y: Int): Int = x - y

  def performMultiplication(x: Int, y: Int): Int = x * y

  println(performArithmeticOper(2, 4, performAddition))
  println(performArithmeticOper(10, 6, performSubtraction))
  println(performArithmeticOper(8, 6, performMultiplication))

  //Funciones Lambda o anónimas:  =>
  println("------- Funciones Lambda ---------------")
  var lista = List.range(1, 25)
  println(lista)
  var pares = lista.filter((i: Int) => i % 2 == 0)
  println(pares)
  var pares1 = lista.filter((i) => i % 2 == 0)
  println(pares1)
  var pares2 = lista.filter(_ % 2 == 0)
  println(pares2)

  /*lista.foreach( (i: Int) => println(i))
  lista.foreach( i => println(i))
  lista.foreach(println(_))
  lista.foreach(println)*/

  println(lista.map(_ * 2))

  //Ejercicio: utilizar find sobre lista para obtener valores dentro rango
  val value = 50
  print(lista.find((i: Int) => i > 5))
  print(lista.find(_ > value))

  lista.find(_ > 50) match {
    case Some(x) => println("El primer valor encontrado: " + x)
    case None => println("Valor inexistente")
  }

  //
  val opt: Option[Int] = Some(5)
  opt match {
    case Some(value) => println(s"Valor " + value)
    case None => println("No hay valor")
  }

  //Devolución de funciones
  def metodo1: Int => Int = {
    (x: Int) => x * 2
  }

  println(metodo1(1))
  val v1 = metodo1
  println(v1(100))

  //Partially Applied Functions
  def calculateSellingPrice(discount: Double, productPrice: Double): Double = {
    (1 - discount / 100) * productPrice
  }

  val discountApplied = calculateSellingPrice(25, _)
  println(discountApplied)
  val sellingPrice = discountApplied(1000)
  println(sellingPrice)
}