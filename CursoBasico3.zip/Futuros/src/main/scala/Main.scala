import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.{Future, Promise}
import scala.util.Random.nextInt
import scala.util.{Failure, Success}

object Main {
  def main(args: Array[String]): Unit = {
    //Ejemplo simple
    /*val futureSum = Future {
      val a = 5
      val b = 10
      a + b
    }

    futureSum.onComplete {
      case Success(value) => println(s"El resultado es: $value")
      case Failure(exception) => println(s"Ha ocurrido un error: ${exception.getMessage}")
    }*/

    //Ejemplo cocción pizza
    /*def cookPizza(timeCooking: Int = 8): Future[String] = Future {
      println("Start cooking pizza....")
      Thread.sleep(nextInt(timeCooking) * 1000)
      "Margarita pizza"
    }

    def work(time: Int = 2): Unit = {
      println("Cooking....")
      Thread.sleep(time * 1000)
      for (_ <- 1 to 3) {
        println("Still working ...")
        Thread.sleep(time * 1000)
      }
      println("Work finished ! Time to eat!")
    }

    val futurePizza: Future[String] = cookPizza()
    futurePizza.onComplete {
      case Success(pizza) => println(s"Your $pizza is done!")
      case Failure(_) => println("There was an error cooking")
    }
    work()*/

    //Ejemplo de sequencia de futures
    /*def getHeader: Future[List[String]] = Future {
      Thread.sleep(2000)
      List("HEADER","Header 1", "Header 2")
    }

    def getBody: Future[List[String]] = Future {
      Thread.sleep(5000)
      List("BODY", "Body 1", "Body 2")
    }

    def getFoot: Future[List[String]] = Future {
      Thread.sleep(3000)
      List("FOOT","Foot 1", "Foot 2")
    }

    def callBackFunc(l: List[String]): Unit = {
      l(0) match {
        case "HEADER" => println("Gestionamos HTML header")
        case "BODY" => println("Gestionanos HTML body")
        case "FOOT" => println("Gestionamos HTML foot")
      }
    }

    var getHtml = Seq(getHeader, getBody, getFoot)
    getHtml.foreach {
      _.onComplete {
        case Success(value) => callBackFunc(value)
        case Failure(e) => println(e.getMessage)
      }
    }

    println("Pulsa una tecla para continuar")
    System.in.read() */

    //Ejercicio Generación nº aleatorio en Future
    /*def calculoAleatorio(maxValue: Int): Future[Int] = Future {
      Thread.sleep(2000)
      println("Futuro que devuelte un Int")
      nextInt(maxValue)
    }

    def callbackPrintAleatorio(s: String): Unit = {
      println(s"Número aleatorio $s")
    }

    calculoAleatorio(25).onComplete {
      case Failure(exception) => println(s"ERROR: ${exception.getMessage}")
      case Success(value) => callbackPrintAleatorio(value.toString)
    }*/

    //Transformar y componer futuros
    /*val futureSum = Future {
      val a = 5
      val b = 10
      println("Estamo en futureSum")
      a + b
    }
    val futureDouble = futureSum.map(result => result * 2)
    Thread.sleep(2000)
    println(futureDouble)
    futureDouble.foreach({
      println
    })

    val futureChained = futureSum.flatMap { result =>
      Future {
        println("Estamos en future chained")
        result * 5
      }
    }
    futureChained.onComplete(println)

    println("Pulsa una tecla para continuar")
    System.in.read()*/

    //for-comprehensions
    /*
    for {
      x <- collection
      y <- anotherCollection
      if condition (optional)
    } yield expression
     */
    val numbers = List(1,2,3,4)
    val chars = List('a','b','c','d')
    val colors = List("black","white")

    val forCominations = for {
      n <- numbers
      c <- chars
      color <- colors
      if n % 2 == 0
    } yield "" + c + n + "-" + color
    println(forCominations)

    val forC = for {
      a <- 1 to 3
      b <- 1  to 3
      c <- 1 to 3
    } yield a.toString + b.toString + c.toString
    println(forC)

    val forC1 = for {
      a <- 1 to 3
      b <- 1 to 3
      c <- 1 to 3
      if c > 1
    } yield a.toString + b.toString + c.toString
    println(forC1)

    val ls = for {
      x <- List(1, 2, 3)
      y <- List(4, 5, 6)
      if x + y > 5
    } yield x * y
    println(ls)

    val ls1 = List(1, 2, 3).flatMap { x =>
      List(4, 5, 6).withFilter(y => x + y > 5).map(y => x * y)
    }
    println(ls1)

    val f1 = Future(10)
    val f2 = Future(20)

    val result = for {
      x <- f1
      y <- f2
    } yield x + y
    result.map(println)

    //metodo flatMap
    val number = List(1,2,3)
    val result1 = number.map(x => List(x, x * 10))
    println(result1)
    val result2 = number.flatMap(x => List(x, x * 10))
    println(result2)

    //Promise: objeto que puede completar un Future
    val promise = Promise[Int]()
    val future = promise.future

    Future {
      Thread.sleep(2000)
      //promise.success(42)
      promise.failure(new Throwable("Forzamos el fallo"))
    }

    future.onComplete {
      case Success(value) => println(s"Resultado del Future: $value")
      case Failure(e) => println(s"Error: ${e.getMessage}")
    }
    println("Pulsar tecla")
    System.in.read()
  }
}