object Main {
  def main(args: Array[String]): Unit = {
    println("Hello world!")

    val x = 10
    val x1: Int = 10
    println(x, x.getClass)
    println(x1, x1.getClass)

    var y = 20
    y = 30

    var vText: String = "Hola Mundos2"
    println(vText)

    lazy val Cons1: Int = 10

    var z = 10.0
    var z1: Double = 10
    println(z, z.getClass)

    //Tuplas
    val tupla = (1, "Scala", true)
    val primerEl = tupla._1
    println(primerEl, tupla._2, tupla._3)

    val (num, palabra, bool) = tupla
    println(num, palabra, bool)

    def obtenerInfo(): (String, Int, Boolean) = {
      ("Scal", 2024, true)
    }

    val (nombre, año, esBool) = obtenerInfo()
    println(s"Nombre: $nombre, Año: $año, Es popular: $esBool")

    //Collections
    val numbers = List(1, 2, 3, 4)
    println(numbers)
    val numbers2 = numbers.map((i: Int) => i * 2)
    println(numbers2)
    numbers2.foreach(println)

    //operadores
    //asignación: =
    //comparaciones: == > z !=

    y = 0
    while (y < 25) {
      println(y)
      y = y + 1
    }

    y = 0
    do {
      println(y)
      y = y + 1
    } while (y < 30)

    for ( z <- 1 to 10 by 2) {
      println(z)
    }
    for ( z <- 1 until 10) {
      println(z)
    }

    if ( x == 10) {
      println("X vale 10")
    } else if (x > 10) {
      println("X mayor 10")
    } else {
      println("X menor 10")
    }

    var color: String = "red"
    color match {
      case "red" => println("Rojo")
      case "blue" => println("Azul")
      case _ => println("Otro color")
    }

    def Nombrefunc(par1: String, par2: String, par3: String): Int = {
      println("Estoy dentro de la funcion")
      if (par1 == "p1" || par1 == "p2") {
        10
      } else {
        5
      }
    }

    println(Nombrefunc("p1", "p2", "p3"))
    println(Nombrefunc(par2="p1", par1="p2", par3="p3"))


    var l: Seq[Int] = Seq(1, 2, 3, 4, 5)
    def NFunc2(s: Seq[Int]): Int = {
      0
    }
    println(NFunc2(l))

  }
}