package Pila

trait PilaTrait[A] {
  def push(vElement: A): Unit
  def print_pila(): Unit
  def pop(): A
  def len_pila(): Int

  override def toString: String = {
    "Pila Trait"
  }
}

trait PilaTrait2[A] {
  def push2(vElement: A): Unit
}

class PilaString extends PilaTrait[String] with PilaTrait2[String] {
  var pila: List[String] =  Nil

  override def toString: String = {
    "Pila String"
  }

  override def push(vElement: String): Unit = {
    pila = pila:+vElement
  }

  override def print_pila(): Unit = {
    pila.foreach(println)
    println(pila.toString())
    println(this.toString())
  }

  override def pop(): String = {
    var p: String = pila.last
    pila = pila.dropRight(1)
    p
  }

  override def len_pila(): Int = {
    pila.length
  }

  override def push2(vElement: String): Unit = ???
}