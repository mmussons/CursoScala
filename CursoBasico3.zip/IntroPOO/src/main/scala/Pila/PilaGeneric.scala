package Pila

import scala.collection.mutable.ListBuffer

class PilaGeneric[A] {
  private var pila: ListBuffer[A] = ListBuffer()

  def push(vElem: A): Unit = {
    pila.append(vElem)
  }

  def pop(): A = {
    var p: A = pila.last
    pila = pila.dropRight(1)
    p
  }

  def print_pila(): Unit = {
    pila.foreach(println)
  }

  def length_pila(): Int = {
    pila.length
  }
}
