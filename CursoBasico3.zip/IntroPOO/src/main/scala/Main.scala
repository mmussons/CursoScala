import Pila.{Pila, PilaGeneric, PilaHerancia, PilaWithLimit, PilaString => PilaS}

import scala.collection.mutable.ListBuffer

object Main {
  def main(args: Array[String]): Unit = {
    //println("Hello world!")

    class Vehiculo(cv: Int, bastidor: String) {
      override def toString: String = {
        "Vehiculo: " + cv + " " + bastidor
      }
    }
    var veh = new Vehiculo(150, "bastidor")
    //println(veh.bastidor)

    class curso(param1: Int, param2: Int) {
      private var param_nuevo: Int = 0

      //Constructor auxiliar
      def this(param1: Int, param2: Int, param_nuevo: Int) {
        this(param1, param2)
        this.param_nuevo = param_nuevo
      }
    }
    var cs = new curso(1,2,3)

    class Empleado() {
      private var id: Int = 0
      private var nombre: String = _
      private var edad: Int = 0

      def this(par_id: Int) {
        this()
        this.id = par_id
      }

      def this(par_id: Int, par_nombre: String, par_edad: Int) {
        this(par_id)
        this.nombre = par_nombre
        this.edad = par_edad
      }

      override def toString: String = {
        id + " " + nombre + " " + edad
      }
    }

    //Pila prog funcional
    var pila_proc: ListBuffer[String] = ListBuffer()

    def push_lb(lb: String): Unit = {
      pila_proc.append(lb)
    }

    def pop_lb(): String = {
      val lb_temp = pila_proc.last
      pila_proc.remove(pila_proc.length - 1)
      lb_temp
    }

    push_lb("Primero")
    pila_proc.append("Segundo")
    pila_proc.foreach(println)
    pop_lb()
    pila_proc.foreach(println)
    pila_proc(0) = "-"      //Accidentalmente
    pila_proc.foreach(println)

    //Pila con POO
    var pmonedas = new Pila()
    pmonedas.push("Euro")
    pmonedas.push("Euro2")
    pmonedas.push("Euro3")
    pmonedas.push("Dollar")
    pmonedas.print_pila()
    println("Eliminado: " + pmonedas.pop())
    pmonedas.print_pila()

    println(pmonedas.length_pila)

    var pmonedas2 = new Pila(ListBuffer("Euro","Dolar","Libra"))
    pmonedas2.print_pila()

    //Pila Generic
    println("----------------- PILA GENERIC ---------------")
    var pInt = new PilaGeneric[Int]
    pInt.push(1)
    pInt.push(2)
    pInt.print_pila()
    println("Longitud pila generic INT: " + pInt.length_pila())
    println("Extraemos último elemento INT: " + pInt.pop())
    pInt.print_pila()
    println("Longitud pila generic INT: " + pInt.length_pila())

    var pStr = new PilaGeneric[String]
    pStr.push("Str1")
    pStr.push("Str2")
    pStr.print_pila()
    pStr.push("Str3")
    println(pStr.length_pila())

    var em = new Empleado(1, "Jose", 3)
    var em2 = new Empleado(1,"Manuel",2)
    var pem = new PilaGeneric[Empleado]
    pem.push(new Empleado(2))
    pem.push(em)
    pem.push(em2)
    println(pem.length_pila())
    pem.print_pila()

    var vh1 = new Vehiculo(10, "XYZ")
    var vh2 = new Vehiculo(20, "ZYX")
    var pvh = new PilaGeneric[Vehiculo]
    pvh.push(vh1)
    pvh.push(vh2)
    pvh.print_pila()

    //HERENCIA
    println("-------HERENCIA-------")
    var ph = new PilaHerancia()
    ph.push("ElemH1")
    ph.push("ElemH2")
    ph.print_pila()
    println("Longitud pila herencia: " + ph.length_pila())
    println("Ultimo elemento lista: " + ph.pila_head())

    var plimit = new PilaWithLimit(3)
    plimit.push("Uno")
    plimit.push("Dos")
    plimit.push("Tres")
    plimit.push("Cuatro")

    //Traits
    println("-------TRAITS-------")
    var tmonedas = new PilaS()  //PilaString pero importado con Alias PilaS
    tmonedas.push("euro")
    println("Longitud pila usando traits string: " + tmonedas.len_pila())
    tmonedas.print_pila()
    //tmonedas.push2("Dollar")

    //Singleton objects: no se pueden instanciar.
    println("-------SINGLETON OBJECTS-------")
    object Pila_msg {
      def prnt(msg: String): Unit = {
        println(msg)
      }
    }

    Pila_msg.prnt("Singleton fuera de una clase")
    pmonedas.Pila_msg1.prnt("Singleton dentro de una clase")
    pmonedas2.Pila_msg1.prnt("Singleton 2 dentro de la clase")

    //Companion objects:
    println("-------COMPANION OBJECTS-------")
    println("MaxSize: " + Pila.PilaMaxSize + " MinSize: " + Pila.PilaMinSize)
    Pila.estatico()

    var pl = Pila()
    pl.push("Dollar")
    pl.push("Euro")
    println(pl.length_pila())

    var pl1 = Pila(ListBuffer("A","B","C"))
    pl1.print_pila()

    //CASE CLASS
    println("----------CASE CLASS ----------")
    case class NuevaPila(pl: Pila, est: String)

    var es = NuevaPila(Pila(), "Texto")
    es.pl.push("Dollar")
    es.pl.print_pila()
    println(es.est)

    case class CovidCountryStats(countryCode: String, deaths: Int, confirmedCases: Int)
    val covidPL = CovidCountryStats("PL", 50, 15000)
    //println(covidPL.confirmedCases)

    //metodo unapply
    covidPL match {
      case CovidCountryStats("PL", x, y) => println("Muertes en Polonia: " + x + " Casos: " + y)
      case _ => println("Pais desconocido")
    }

    val covidUA = covidPL.copy(countryCode = "UA")
    val tuple = ("PL",25,1000)
    val covidPL2 = (CovidCountryStats.apply _).tupled(tuple)
  }
}