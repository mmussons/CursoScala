object Main extends App{

  /*Sintaxi excepciones
  try {
    Bloque de Codigo que queremos ejecutar
  } catch {
    Código que se ejecuta en caso de excepción
  } finally {
    Siempre se ejecuta este código
  }
   */

  def dividir (n1: Int, n2: Int): Float = {
    n1/n2
  }

  def pedirEdad(edad: Int): Unit = {
    if (edad < 18) {
      throw new Exception("Edad incorrecta")
    }
    println("Edad correcta!!!")
  }

  try {
    println(dividir(10, 1))
    val array1= Array(1,5,7)
    array1(90)
    pedirEdad(15)
  } catch {
    case ex: ArithmeticException => println("Se ha producido la excepción: " + ex)
    case ex0: Exception => println("Se ha producido la Exception " + ex0)
    case ex1: Throwable => println("Se ha producido el Throwable: " + ex1)
  } finally {
    println("Finally: se ejecuta siempre")
  }
}