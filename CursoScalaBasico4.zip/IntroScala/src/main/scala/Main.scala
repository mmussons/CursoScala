import scala.collection.mutable.ListBuffer

object Main {
  def main(args: Array[String]): Unit = {
    println("Hello world!")

    val x = 10
    val x1: Int = 10
    println(x, x.getClass)
    println(x1, x1.getClass)

    var y = 10
    y = 20

    var vText: String = "Hola"
    println(vText)

    lazy val Cons1: Int = 10

    //Tuplas: inmutable
    val tupla = (1, "Scala", true)
    val primerEl = tupla._1
    println(primerEl, tupla._2, tupla._3)

    val (num, palabra, bool) = tupla

    def obtenerInfo(): (String, Int, Boolean) = {
      ("Scala", 2024, true)
    }
    val (nombre, año, esPopular) = obtenerInfo()
    println(s"Nombre: $nombre, Año: $año, Es popular: $esPopular")

    //Scala Collections
    val number2 = List(1,2,3,4)
    println(number2)

    val number3 = ListBuffer(1,2,3,4)
    number3.append(5)
    println(number3)

    val number4 = number3.map((i: Int) => i * 2)
    println(number4)

    //Operadore
    //Asignación: =
    //Comparación: == != >

    y = 0
    //Estructuras de control
    while (y < 25) {
      println(y)
      y = y + 1
    }

    y = 0
    do {
      println(y)
      y = y + 1
    } while (y < 30)

    for (z <- 1 to  10 by 2) {
      println(z)
    }
    for (z <- 1 until 10) {
      println(z)
    }

    if (x == 10) {
      println("X vale 10")
    } else if (x > 10) {
      println("X mayor 10")
    } else {
      println("X menor 10")
    }

    //Pattern matching
    val color: String = "red"
    color match {
      case "red" => println("Rojo")
      case "blue" => println("Azul")
      case _ => println("Otro")
    }

    def NombreFunc(par1: String, par2: String, par3: String): Int = {
      if (par1 == "p1" || par2 == "p2") {
        10
      } else {
        5
      }
    }

    println(NombreFunc("p1","p2","p3"))
    println(NombreFunc(par2="p1",par3="p2",par1="p3"))

    var l: Seq[Int] = Seq(1,2,3,4,5)
    def NFunc2(s: Seq[Int]): Int = {
      0
    }

    println(NFunc2(l))
  }
}