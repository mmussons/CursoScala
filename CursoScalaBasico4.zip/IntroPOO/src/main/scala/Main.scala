import Pila.{Pila, PilaGeneric, PilaHerencia, PilaWithLimit, PilaString => PilaS}

import scala.collection.mutable.ListBuffer

object Main {
  def main(args: Array[String]): Unit = {
    println("Hello world!")

    //Vehiculo
    class vehiculo(cv: Int, bastidor: String) {
      override def toString: String = {
        "Cavallos: " + cv + " Bastidor: " + bastidor
      }
    }
    var veh = new vehiculo(150, "XLK0983ur")

    //println(veh.bastidor)

    //Constructores auxliares
    class curso(param1: Int, param2: Int) {
      private var param_nuevo: Int = 0

      def this(param1: Int, param2: Int, param_nuevo: Int) {
        this(param1,param2)
        this.param_nuevo = param_nuevo
      }
    }

    //Constructores múltiples
    class Empleado() {
      private var id: Int = 0
      private var nombre: String = _
      private var edad: Int = 0

      def this(par_id: Int) {
        this()
        this.id = par_id
      }

      def this(par_id: Int, par_nombre: String, par_edad: Int) {
        this(par_id)
        this.nombre = par_nombre
        this.edad = par_edad
      }

      override def toString: String = {
        "Id: " + id + " Nombre: " + nombre + " Edad: " + edad
      }
    }

    var empl = new Empleado(1, "MAnuel", 40)
    var empl2 = new Empleado(2)

    //Pila con programación procedimental
    var pila_proc: ListBuffer[String] = ListBuffer()

    def push_lb(lb: String): Unit = {
      pila_proc.append(lb)
    }

    def pop_lb(): String = {
      val lb_temp = pila_proc.last
      pila_proc.remove(pila_proc.length - 1)
      lb_temp
    }

    push_lb("Primero")
    push_lb("Segundo")
    pila_proc.foreach(println)
    println(pop_lb())
    pila_proc.foreach(println)
    pila_proc.append("Tercero")
    pila_proc(0) = "-"
    pila_proc.foreach(println)

    //Pila con programación orientada objetos
    println("----------POO---------")
    var pmonedas = new Pila()
    pmonedas.push("Euro")
    pmonedas.push("Dollar")
    pmonedas.push("Libra")
    pmonedas.print_pila()
    println("Eliminamos: " + pmonedas.pop())
    pmonedas.print_pila()
    println("Tamaño pila: " + pmonedas.length_pila())

    var pmonedas2 = new Pila(ListBuffer("Euro2","Dollar2", "Libra2"))
    pmonedas2.print_pila()

    println("----------PILA GENERIC---------")
    println("----------PILA GENERIC INT---------")
    var pInt = new PilaGeneric[Int]
    pInt.push(1)
    pInt.push(2)
    pInt.print_pila()
    println("Longitud pila INT: " + pInt.length_pila())
    println("Extraemos: INT" + pInt.pop())
    pInt.print_pila()
    println("Longitud pila INT: " + pInt.length_pila())

    println("----------PILA GENERIC String--------")
    var pStr = new PilaGeneric[String]
    pStr.push("Str1")
    pStr.push("Str2")
    pStr.print_pila()
    pStr.push("Str3")
    println(pStr.length_pila())

    println("----------PILA GENERIC Empleados---------")
    var pem = new PilaGeneric[Empleado]
    pem.push(new Empleado(2))
    pem.push(empl)
    pem.push(empl2)
    println(pem.length_pila())
    pem.print_pila()

    var vh1 = new vehiculo(10, "XYZ")
    var vh2 = new vehiculo(20, "ZXY")
    var phv = new PilaGeneric[vehiculo]
    phv.push(vh1)
    phv.push(vh2)
    phv.print_pila()

    //HERENCIA
    println("------------PILA HERENCIA--------")
    var ph = new PilaHerencia()
    ph.push("ElemHerencia1")
    ph.push("ElemHerencia2")
    ph.print_pila()
    println("Longitud pila herencia: " + ph.length_pila())
    println("Ultimo elemento de la pila: " + ph.pila_head())

    println("------------PILA HERENCIA CON LIMITE DE ELEMENTOS --------")
    var plimit = new PilaWithLimit(3)
    plimit.push("Uno")
    plimit.push("Dos")
    plimit.push("Tres")
    plimit.push("Cuatro")

    //Traits
    println("------TRAITS-----------")
    var tmonedas = new PilaS()
    tmonedas.push("Euro")
    tmonedas.push("Dollar")
    println("Longitud pila Traits: " + tmonedas.length_pila())
    tmonedas.print_pila()
    //tmonedas.push2("Dollar")

    //Object
    //Singleton object
    println("-----SINGLETON OBJECT------")
    object Pila_msg {
      def prnt(msg: String): Unit = {
        println(msg)
      }
    }

    Pila_msg.prnt("Singleton object fuera de una classe")
    pmonedas.Pila_msg1.prnt("Singleton object dentro de una class")
    pmonedas2.Pila_msg1.prnt("Singleton 2 object dentro de class")

    //Companion object
    println("--------COMPANION OBJECT--------")
    println(Pila.PilaMaxSize + " " + Pila.PilaMinSize)
    Pila.estatico()

    var pl = Pila()
    println(pl.length_pila())
    var pl1 = Pila(ListBuffer("A","B","C"))
    pl1.print_pila()

    //CASE CLASS: creamos la classe + object companion
    println("------- CASE CLASS ------")
    case class NuevaPila(pl: Pila, estado: String)

    var es = NuevaPila(Pila(), "Vacia")
    es.pl.push("Dollar")
    es.pl.print_pila()
    println(es.estado)

    //metodo unapply de case class
    case class CovidCountryStats(countryCode: String, deaths: Int, confirmedCases: Int)
    val covidPL = CovidCountryStats("PL", 50, 15000)
    //println(covidPL.confirmedCases)

    covidPL match {
      case CovidCountryStats("PL", x, y) => println("El ratio de muertes en Polonia es: " + x.toFloat / y.toFloat)
      case _ => println("Pais desconocido")
    }

    val covidUA = covidPL.copy(countryCode = "UA")
    println(covidPL.countryCode, covidPL.confirmedCases, covidPL.deaths)
    println(covidUA.countryCode, covidUA.confirmedCases, covidUA.deaths)

    val tuple = ("ES", 20,20000)
    val covidES = (CovidCountryStats.apply _).tupled(tuple)
    println(covidES.countryCode, covidES.confirmedCases, covidES.deaths)
  }
}