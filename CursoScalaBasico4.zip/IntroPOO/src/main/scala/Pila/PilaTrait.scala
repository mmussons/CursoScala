package Pila

trait PilaTrait[A] {
  def push(vElement: A): Unit
  def print_pila(): Unit
  def pop(): A
  def length_pila(): Int
}

trait PilaTrait2[A] {
  def push2(vElement: A): Unit
}

class PilaString extends PilaTrait[String] with PilaTrait2[String] {
  var pila: List[String] = Nil

  override def push(vElement: String): Unit = {
    pila = pila:+vElement
  }

  override def print_pila(): Unit = {
    pila.foreach(println)
  }

  override def pop(): String = {
    var p: String = pila.last
    pila = pila.dropRight(1)
    p
  }

  override def length_pila(): Int = {
    pila.length
  }

  override def push2(vElement: String): Unit = ???
}
