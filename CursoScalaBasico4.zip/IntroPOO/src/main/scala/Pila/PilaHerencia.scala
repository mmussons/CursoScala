package Pila

class PilaHerencia extends Pila {
  override def print_pila(): Unit = {
    //super.print_pila()
    pila.foreach(p => println("Herencia: " + p))
  }

  def pila_head(): String = {
    pila.head
  }
}

class PilaWithLimit(Limit: Int) extends Pila {
  override def push(vElem: String): Unit = {
    if (this.length_pila() < Limit) {
      super.push(vElem)
    } else {
      println("NO se pueden añadir más elementos. Pila completa!!!")
    }
  }
}