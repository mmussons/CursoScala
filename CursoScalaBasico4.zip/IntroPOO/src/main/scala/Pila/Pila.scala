package Pila

import scala.collection.mutable.ListBuffer

class Pila {
  protected var pila: ListBuffer[String] = ListBuffer()

  def this(p: ListBuffer[String]) {
    this()
    this.pila = p
  }

  def push(vElem: String): Unit = {
    pila.append(vElem)
  }

  def pop(): String = {
    var p: String = pila.last
    pila = pila.dropRight(1)
    p
  }

  def print_pila(): Unit = {
    pila.foreach(println)
  }

  def length_pila(): Int = {
    pila.length
  }

  object Pila_msg1 {
    def prnt(msg: String): Unit = {
      println(msg)
    }
  }
}

//Object companion
object Pila {
  val PilaMaxSize = 100
  val PilaMinSize = 0

  def estatico(): Unit = {
    println("Companion objecrt")
  }

  def apply(): Pila = {
    val pila1 = new Pila()
    pila1
  }

  def apply(p: ListBuffer[String]): Pila = {
    val pila1 = new Pila(p)
    pila1
  }
}