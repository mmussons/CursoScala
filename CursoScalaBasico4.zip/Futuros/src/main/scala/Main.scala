import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.{Future, Promise}
import scala.util.Random.nextInt
import scala.util.{Failure, Success}

object Main {
  def main(args: Array[String]): Unit = {
    //Futures
    //Ejemplo simple
    /*val futureSum = Future {
      val a = 5
      val b = 10
      a + b
    }

    futureSum.onComplete {
      case Success(value) => println(s"El resultado es: $value")
      case Failure(exception) => println(s"Ha ocurrido un error: ${exception.getMessage}")
    }*/

    //
    /*def cookPizza(timeCooking: Int = 8): Future[String] = Future {
      println("Start cooking pizza...")
      Thread.sleep(nextInt(timeCooking) * 1000)
      "Margarita pizza"
    }

    def work(time: Int = 2): Unit = {
      println("Cooking ....")
      Thread.sleep(time * 1000)
      for (_ <- 1 to 3) {
        println("Still working....")
        Thread.sleep(time * 1000)
      }
      println("Work finished!")
    }

    val futurePizza: Future[String] = cookPizza()
    futurePizza.onComplete {
      case Success(pizza) => println(s"Your $pizza is done!")
      case Failure(e) => println("There was an error cooking" + e.getMessage)
    }
    work()*/

    //Ejemplo sequencia de Futures
    /*def getHeader: Future[List[String]] = Future {
      Thread.sleep(2000)
      List("HEADER", "Header 1", "Header 2")
    }

    def getBody: Future[List[String]] = Future {
      Thread.sleep(5000)
      List("BODY", "body 1","body 2")
    }

    def getFoot: Future[List[String]] = Future {
      Thread.sleep(3000)
      List("FOOT", "Foot 1", "Foot 2")
    }

    def callBackFunc(l: List[String]): Unit = {
      l(0) match {
        case "HEADER" => println("Gestionamos HTML header")
        case "BODY" => println("Gestionamos HTML body")
        case "FOOT" => println("Gestionamos HTML foot")
      }
    }

    var getHtml = Seq(getHeader, getBody, getFoot)
    getHtml.foreach {
      _.onComplete {
        case Success(value) => callBackFunc(value)
        case Failure(e) => println(e.getMessage)
      }
    }*/

    //Ejercicio: Generación nº aleatorioa en un future
    /*def calcAleatorio(valor: Int): Future[Int] = Future {
      Thread.sleep(3000)
      println("Futuro que devuelve un Int")
      nextInt(valor)
    }

    def callBackAleatorio(valor: String): Unit = {
      println(s"Número aleatorio es: $valor")
    }

    calcAleatorio(25).onComplete {
      case Success(value) => callBackAleatorio(value.toString)
      case Failure(exception) => println("ERROR: " + exception.getMessage)
    }

    println("Pulsa una tecla")
    System.in.read()*/

    //Transformacion (map) y composición (flatMap) de futures
    val futureSum = Future {
      val a = 5
      val b = 10
      a + b
    }
    val futureDouble = futureSum.map(result => result * 2)
    println(futureDouble)
    futureDouble.foreach({
      println
    })

    val futureChained = futureSum.flatMap { result =>
      Future {
        result * 5
      }
    }
    Thread.sleep(1000)
    futureChained.onComplete(println)
    futureChained.onComplete {
      case Success(value) => println(s"Valor $value")
    }

    //Ejemplo metodos map y flapMap
    val numbers = List(1,2,3)
    val result = numbers.map(x => List(x, x * 10))
    println(result)
    val result1 = numbers.flatMap(x => List(x, x * 10))
    println(result1)

    //for-comprehension
    /*
      Estructura básica
      for {
        x <- collection
        y <- anotherCollection
        if codition
      } yield expression
     */
    println("---------FOR COMPREHENSION-------")
    val numbers1 = List(1,2,3,4)
    val chars = List('a','b','c')
    val colors = List("black","white")

    val forCombinations = for {
      n <- numbers1
      c <- chars
      color <- colors
    } yield "" + c + n + "-" + color
    println(forCombinations)

    val forCombinations1 = for {
      n <- numbers1
      c <- chars
      color <- colors
      if n % 2 == 0
    } yield "" + c + n + "-" + color
    println(forCombinations1)

    val forC = for {
      a <- 1 to 3
      b <- 1 to 3
      c <- 1 to 3
    } yield a.toString + b.toString + c.toString
    println(forC)

    val forC1 = for {
      a <- 1 to 3
      b <- 1 to 3
      c <- 1 to 3
      if c > 1
    } yield a.toString + b.toString + c.toString
    println(forC1)

    val ls1 = List(1,2,3).flatMap { x =>
      List(4,5,6).withFilter(y => x + y > 5).map(y => x * y)
    }
    println(ls1)
    val ls2 = List(1,2).flatMap { x =>
      List(4, 5, 6)
    }
    println(ls2)

    val ls = for {
      x <- List(1,2,3)
      y <- List(4,5,6)
      if x + y > 5
    } yield x * y
    println(ls)

    //for-comprehension para futures
    val f1 = Future(10)
    val f2 = Future(20)

    val res = for {
      x <- f1
      y <- f2
    } yield x + y
    res.map(println)

    //Promise: un objeto que puede completar un Future
    val promise = Promise[Int]()
    val future = promise.future

    Future {
      Thread.sleep(1000)
      promise.success(42)
      //promise.failure(new Throwable("Forzamos el fallo del Future"))
    }

    future.onComplete {
      case Success(value) => println(s"Resultado del Future: $value")
      case Failure(exception) => println(s"Error: ${exception.getMessage}")
    }

    println("Pulsa una tecla")
    System.in.read()
  }
}