import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.{col, substring_index}

case class ApacheLogRecord(ip: String, date: String, request: String, referrer: String)

object SparkLogFile extends App {
  val spark = SparkSession.builder()
    .appName("Log File Demo")
    .master("local[3]")
    .getOrCreate()

  val logDF = spark.read.textFile("src/datos/apache_logs.txt").toDF()

  val myReg = """^(\S+) (\S+) (\S+) \[([\w:/]+\s[+\-]\d{4})\] "(\S+) (\S+) (\S+)" (\d{3}) (\S+) "(\S+)" "([^"]*)"""".r

  import spark.implicits._

  val logsDF =logDF.map(row =>
    row.getString(0) match {
      case myReg(ip, client, user, date, cmd, request, proto, status, bytes, referrer, userAgent) =>
        (ip, date, request, referrer)
    }
  )
  logsDF.show()

  val logsDF1 = logDF.map(row =>
    row.getString(0) match {
      case myReg(ip, client, user, date, cmd, request, proto, status, bytes, referrer, userAgent) =>
        ApacheLogRecord(ip, date, request, referrer)
    }
  )
  logsDF1.show(truncate = false)

  logsDF1
    .where("trim(referrer) != '-' ")
    .groupBy("referrer").count().show(truncate = false)

  logsDF1
    .where("trim(referrer) != '-' ")
    .withColumn("referrer", substring_index(col("referrer"),"/",3))
    .groupBy("referrer").count().show(truncate = false)

}
