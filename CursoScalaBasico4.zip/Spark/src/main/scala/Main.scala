import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.{DataFrame, SparkSession}

import java.util.Properties
import scala.io.Source

object Main {
  val logger: Logger = Logger.getLogger(getClass.getName)

  def main(args: Array[String]): Unit = {
    println("Hello world!")
    //Ejemplo alias: solo informativo
    type ls = List[String]
    val z: ls = List("a", "b")

    //1 versión crear spark session
    /*var spark = SparkSession.builder()
      .appName("Hello  spark")
      .master("local[3]")
      .getOrCreate()*/

    //2 versión
    val sparkAppConfig = new SparkConf()
    /*sparkAppConfig.setAppName("Hello Spark")
    sparkAppConfig.setMaster("local[3]")*/

    //3 versión
    /*sparkAppConfig
      .set("spark.app.name","Hello spakr")
      .set("spark.master","local[3]")*/

    val spark = SparkSession.builder()
      //.config(sparkAppConfig)
      .config(getSparkAppConf)
      .getOrCreate()

    //LECTURA Y PROCESADO
    val fileCsv = "src/datos/sample.csv"
    val surveyDF = spark.read
      .option("header","true")
      .option("inferSchema","true")
      .csv(fileCsv)
    //surveyDF.show()

    val surveyRawDF = loadSurveyDF(spark, fileCsv)
    //surveyRawDF.show()

    val partitionedSurveyDF = surveyRawDF.repartition(2)

    val selectSurveyRawDF = surveyRawDF.select("Age","Gender", "Country", "state")
    val filteredSurveyRawDF = selectSurveyRawDF.filter("Age < 40")
    //filteredSurveyRawDF.show()
    val groupedSurveyRawDF = filteredSurveyRawDF.groupBy("Country")
    val countDF = groupedSurveyRawDF.count()
    countDF.show()

    val countDF1 = countByCountry(partitionedSurveyDF)
    countDF1.foreach(row => {
      logger.info("Country: " + row.getString(0) + " Count: " + row.getLong(1))
    })
    logger.info(countDF1.collect().mkString("->"))

    //otro ejemplo
    surveyRawDF.printSchema()
    surveyRawDF.createTempView("sampleUsers")
    val sampleSqlDF = spark.sql("select Age, Gender, Country, state from sampleUsers where Age < 40")
    sampleSqlDF.show()

    spark.stop()
  }

  def countByCountry(surveyDF: DataFrame): DataFrame = {
    surveyDF.where("Age < 40")
      .select("Age","Gender","Country","state")
      .groupBy("Country")
      .count()
  }

  //Leemos archivo spark.conf de disco
  def getSparkAppConf: SparkConf = {
    val sparkAppConf = new SparkConf()
    val props = new Properties()
    props.load(Source.fromFile("spark.conf").bufferedReader())
    props.forEach((k, v) => sparkAppConf.set(k.toString, v.toString))
    sparkAppConf
  }

  def loadSurveyDF(spark: SparkSession, dataFile: String): DataFrame = {
    spark.read
      .option("header", "true")
      .option("inferSchema", "true")
      .csv(dataFile)
  }
}