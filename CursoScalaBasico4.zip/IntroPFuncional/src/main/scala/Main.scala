object Main extends App {
  //Funcion pura
  def suma(a: Int, b: Int): Int = a + b

  //Def funciones
  //Sintaxis explicita
  val x = 0
  val x1: Int = 0

  val getNameLengthVal: (String, String) => Int = (name, name1) => name.length + name1.length
  val multiplyByTwoVal: Int => Int = numero => numero * 2

  //Sintaxi implicita
  val getNameLengthVal2 = (name: String, name1: String) => name.length + name1.length
  val multiplyByTwoVal2 = (numero: Int) => numero * 2

  println(getNameLengthVal("Scala", "Scala"))
  println(multiplyByTwoVal(2))

  println(getNameLengthVal2("Scala", "Scala"))
  println(multiplyByTwoVal2(2))

  //Funcional vs POO
  trait MyFunction[A, B] {
    def apply(element: A): B
  }

  /*class doubler(element: Int) extends MyFunction[Int, Int] {
    override def apply(element: Int): Int = element * 2
  }*/

  var doubler = new MyFunction[Int, Int] {
    override def apply(element: Int): Int = element * 2
  }

  println(doubler.apply(2))
  println(doubler(2))

  //
  val stringToIntConverter = new Function[String, Int] {
    override def apply(v1: String): Int = v1.toInt
  }
  println(stringToIntConverter("3") * 7)

  //implicita
  val adder = new Function2[Int, Int, Int] {
    override def apply(v1: Int, v2: Int): Int = v1 + v2
  }
  println(adder(1,2))

  //explícita
  val adder2: Function2[Int, Int, Int] = new Function2[Int, Int, Int] {
    override def apply(v1: Int, v2: Int): Int = v1 + v2
  }
  println(adder2(1,2))

  val adder3: ((Int, Int) => Int) = new Function2[Int, Int, Int] {
    override def apply(v1: Int, v2: Int): Int = v1 + v2
  }
  println(adder3(1,2))

  //Resumen: Function2[A, B, R] traducible a (A, B) => R
  val adder4: (Int, Int) => Int = (v1, v2) => v1 + v2
  val adder5 = (v1: Int, v2: Int) => v1 + v2
  println(adder4(1,2))
  println(adder5(1,2))

  //Higher-Order functions
  def calcAnything(number: Int, calcFunction: Int => Int): Int = calcFunction(number)
  def calcSquare(num: Int): Int = num * num
  def calcCube(num: Int): Int = num * num * num
  //def calcLenStr(str: String): Int = str.length

  var squareCalculated = calcAnything(2, calcSquare)
  val cubeCalculated = calcAnything(2, calcCube)
  //val strCalculated = calcAnything(3, calcLenStr)

  println(squareCalculated, cubeCalculated)

  //Ejercicio: funcion sumas, restar y mulpliciar

  def performArithmeticOper(num1: Int, num2: Int, f: (Int, Int) => Int): Int = f(num1, num2)
  def performAddition(x: Int, y: Int): Int = x + y
  def performSubtraction(x: Int, y: Int): Int = x - y
  def performMultiplication(x: Int, y: Int): Int = x * y

  println("Sumamos: " + performArithmeticOper(2, 4, performAddition))
  println("Restamos: " + performArithmeticOper(10, 6, performSubtraction))
  println("Multiplicamos: " + performArithmeticOper(8, 6, performMultiplication))

  //Devolucion de funciones
  def metodo1: Int => Int = {
    (x: Int) => x * 2
  }

  println(metodo1(1))
  val v1 = metodo1
  println(v1(100))

  //Funciones anónimas o LAMBDA: =>
  println("----- FUNCIONES LAMBDA --------")
  var lista = List.range(1,25)
  println(lista)
  println(10 % 2 == 0)
  println(9 % 2 == 0)
  var lista_pares = lista.filter( (i: Int) => i % 2 == 0)
  println(lista_pares)
  var lista_pares1 = lista.filter( (i) => i % 2 == 0)
  println(lista_pares1)
  var lista_pares2 = lista.filter( _ % 2 == 0 )
  println(lista_pares2)

  /*lista.foreach( (i: Int) => println(i) )
  lista.foreach( i => println(i) )
  lista.foreach(println(_))
  lista.foreach(println)*/

  //ejercicio: map para aplicar operación a elementos de la lista
  println(lista.map(_ * 2))

  //ejercicio: find para encontrar el primer elemento que cumple una condición
  val value = 5
  println(lista.find(_ > value))

  lista.find(_ > value) match {
    case Some(x) => println("El primer valor encontrado: " + x)
    case None => println("Valor inexistente")
  }

  def miFuncion(i: Int): Option[Int] = {
    if (i < 10) {
      Some(i)
    } else {
      None
    }
  }
  miFuncion(15) match {
    case Some(x) => println("El primer valor encontrado: " + x)
    case None => println("Valor inexistente")
  }

  //Composición de funciones
  println("---COMPOSICION----")
  val sumar = (x: Int) => x + 1
  val multiplicar = (x: Int) => x * 2
  val resultado = sumar.andThen(multiplicar)
  println(resultado(3))

  println("------RECURSIVIDAD------")
  //Ejemplo de bucle (con variables mutables)
  var suma = 0
  for (i <- 1 to 10) {
    suma += i
  }
  println("Suma con bucle: " + suma)

  //Ejemplo de recursión (sin variables mutables)
  def SumaRecursiva(n: Int): Int = {
    if (n == 0) 0
    else n + SumaRecursiva(n - 1)
  }
  println("Suma recursiva " + SumaRecursiva(10))

  //Partially Applied Functions
  println("--------Partially Applied Functions---------")
  def calculateSellingPrice(discount: Double, productPrice: Double): Double = {
    (1 - discount / 100) * productPrice
  }

  val discountApplied = calculateSellingPrice(25, _)
  val sellingPrice = discountApplied(1000)
  println(sellingPrice)

  def wrap(prefix: String, html: String, suffix: String): String = {
    prefix + html + suffix
  }
  val wrapWithDiv0 = wrap("<div>",_,"</div>")
  println(wrapWithDiv0("Contenido dinámico obtenido de BD"))
}