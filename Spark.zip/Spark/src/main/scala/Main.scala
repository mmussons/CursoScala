object Main {
  def main(args: Array[String]): Unit = {
    println("Hello world!")
  }
}